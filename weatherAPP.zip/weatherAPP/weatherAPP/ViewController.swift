//
//  ViewController.swift
//  weatherAPP
//
//  Created by mac on 11/19/22.
//

import UIKit
import CoreLocation
import Alamofire
import SwiftyJSON
import SwiftSpinner


class ViewController: UIViewController, CLLocationManagerDelegate, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var txtLocation: UITextField!
    @IBOutlet weak var lblLocation: UILabel!
    
    
    let locationManager = CLLocationManager()
    var lat: CLLocationDegrees?
    var lng: CLLocationDegrees?
    var temps = [String]();
    
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestLocation()
    }
    

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        
         lat = location.coordinate.latitude
         lng = location.coordinate.longitude
        
    }
    
    @IBAction func getLocation(_ sender: Any) {
        let apiKey = "AYQR6QM5KHFYVPH9M4EXXJUCC"
                var url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast?locations="
                url += String(format: "%f", lat!) + "," + String(format: "%f", lng!)
                url += "&aggregateHours=24&unitGroup=us&shortColumnNames=false&contentType=json&key="
                url += apiKey
                
                SwiftSpinner.show("Getting Weather Values")
                
                AF.request(url).responseJSON { responseData in

                    SwiftSpinner.hide()
                    if responseData.error != nil {
                        print(responseData.error!)
                        return
                    }
                    
                    let weatherData = JSON(responseData.data as Any)
                    let forecastValues =  weatherData["locations"][String(format: "%f", self.lat!) + "," + String(format: "%f", self.lng!)]["values"]

                    print(forecastValues.count)

                    self.temps = [String]()
                    for forecast in forecastValues {
                        print(forecast)
                        
                        let forecastJSON = JSON(forecast.1)
                        let temp = forecastJSON["temp"].floatValue
                        let condition = forecastJSON["condition"].stringValue
                        let str = "Temperature = \(temp) °F, \(condition)"
                        self.temps.append(str)
                    }
                    self.tblView.reloadData()
        }
        

    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    
    @IBAction func getWeather(_ sender: Any) {
        let cityName = txtLocation.text!
        let apiKey = "AYQR6QM5KHFYVPH9M4EXXJUCC"
        
        var url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast?locations=Herndon,VA,20170&aggregateHours=24&unitGroup=us&shortColumnNames=false&contentType=json&key=YOURAPIKEY"
        
        url += cityName
        url += "&aggregateHours=24&unitGroup=us&shortColumnNames=false&contentType=json&key=AYQR6QM5KHFYVPH9M4EXXJUCC"
        url += apiKey
        
        SwiftSpinner.show("Getting Weather Values")
        
        AF.request(url).responseJSON { responseData in
            
            //print(responseData)
            SwiftSpinner.hide()
            
            if responseData.error != nil {
                
                print(responseData.error!)
                
                return
                
            }
            
            let weatherData = JSON(responseData.data as Any)
                        
            let forecastValues =  weatherData["locations"][self.txtLocation.text!]["values"]
            
            
            print(forecastValues.count)
            
            self.temps = [String]()
            
            for forecast in forecastValues {
                print(forecast)
                
                let forecastJSON = JSON(forecast.1)
                
                let temp = forecastJSON["temp"].floatValue
                
                let condition = forecastJSON["condition"].stringValue
                let str = "Temperature = \(temp), \(condition)"
                self.temps.append(str);
            }
            self.tblView.reloadData();
        }
    }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return temps.count;
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = temps[indexPath.row]
            return cell
        }
    }
